import json
import urllib.parse
import boto3
import pymysql
import csv
import os


secrets_client = boto3.client("secretsmanager")



def get_value(name, stage=None):

    try:
        kwargs = {'SecretId': name}
        if stage is not None:
            kwargs['VersionStage'] = stage
        response = secrets_client.get_secret_value(**kwargs)
        rds_credentials = json.loads(response['SecretString'])
        return rds_credentials
    except Exception as e:
        print(e)


s3 = boto3.client('s3')


def lambda_handler(event, context):
    
    rds_credentials = get_value(os.environ['RDS_SECRET_MANAGER'])
    
    #Get Database Connection
    db_connection = None
    try:
        db_connection = pymysql.connect(host=rds_credentials['rds_writer_endpoint'], user=rds_credentials['rds_username'], password=rds_credentials['rds_password'], db=rds_credentials['rds_db'])
    except pymysql.MySQLError as e:
        print(e)
        print("ERROR: Unexpected error: Could not connect to MySQL instance.")
        raise e

    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key'] 
    download_path = '/tmp/{}'.format(key)

    s3.download_file(bucket, key, download_path)

    with open(download_path, encoding="utf8") as f:
        csv_reader = csv.reader(f)
        with db_connection.cursor() as cur:
            # skip the first row
            next(csv_reader)
            # show the data
            for customer in csv_reader:
                try:
                    print (str(customer))
                    cur.execute('insert into customer (title, firstname, lastname, status, email, age) values("'+str(customer[0])+'", "'+str(customer[1])+'", "'+str(customer[2])+'", "'+str(customer[3])+'", "'+str(customer[4])+'", "'+str(customer[5])+'")')
                    db_connection.commit()
                except Exception as e:
                    print(e)
            
        
    
   
    

